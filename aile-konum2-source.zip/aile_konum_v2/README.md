# Aile Konum 2 — Firebase Realtime Database

**Durum:** Kaynak kod ve derleme taslağı. Fiziksel OPPO cihazında test edilmeden güvenilir/günlük kullanım için önerilmez.

Önceki `Aile Konum v1` (com.omer.ailekonum) yerinde kalır. Yeni paket adı `com.omer.ailekonum2`.

## Neyi çözer?

- ntfy.sh üzerinden her gün gelen HTTP 429 hatasına bağımlı değildir.
- Firebase Realtime Database ile canlı konum ve ayrı bağlantı/durum sinyali.
- GPS ve NETWORK sağlayıcıları, 60 saniyelik kontrol döngüsü, 90 saniyeden eski konuma uyarı.
- Konum verisi AES-256-GCM ile cihazda şifrelenir; Firebase sadece şifreli metni saklar.
- Alıcıya telefon bağlı mı, gerçek GPS ne zaman ölçüldü, pil ve doğruluk gösterilir.
- Arka planda görünür konum servisi; boot receiver ve START_STICKY.
- İnternet yokken eski konum yeniymiş gibi gösterilmez.

## Sıfır ücretli Firebase hesabı kurulumu (Spark)

1. `https://console.firebase.google.com/` adresine kendi Google hesabınızla gidip yeni proje açın. **Ücretli Blaze planına geçmeyin.**
2. Android uygulaması `com.omer.ailekonum2` adıyla Firebase'e kaydedildi; indirilen `google-services.json` bu pakete dahil edildi. SHA-1 bu örnek için gerekmiyor.
3. Build > Authentication > Sign-in method > **Email/Password** etkinleştirin. Kullanıcılar bölümünde **iki ayrı hesap** oluşturun: Konum Gönderen (`sifirdandeneme1@gmail.com`) ve Ortak Takip (`sifirdandeneme2@gmail.com`). Bunların şifrelerini projeye veya GitHub’a yazmayın.
4. Build > Realtime Database > Create database, konum/bölge seçin. Veritabanının tam HTTPS URL'sini kopyalayın. Database > Rules sekmesine `database.rules.json` içeriğini yapıştırıp yayımlayın. Bu dosya belirtilen iki UID için yalnızca `/families/babam` yoluna erişim tanır: gönderen yazabilir, takip hesabı okuyabilir. **Asla herkese açık okuma/yazma kuralı kullanmayın.**
5. Firebase bağlantı dosyası **kaynak pakete `app/src/main/assets/google-services.json` yolunda eklenmiştir**. Bu proje `FirebaseOptions` ile bu dosyadan otomatik bağlantı kurar; uygulama kurulunca JSON metni yapıştırılmaz. Bu dosyayı genel erişimli bir depoya kontrolsüz yüklemeyin.
6. Konum gönderen rolünü seçin, Firebase’de önceden oluşturulmuş **Konum Gönderen** e-posta ve şifresiyle bir defa giriş yapın. Uygulama rastgele **40 haneli** ayrı bir veri şifreleme anahtarı üretir. **Uygulama Firebase hesabı oluşturmaz.**
7. Android'den konuma “Her zaman izin ver” yetkisini ayarlayın, pil optimizasyonunu kapatın ve OPPO'da otomatik başlatmaya izin verin. Başlat'a basın.
8. Konum gönderenin ekranında **Davet metnini paylaş** butonunu kullanın. Aile üyeleri aynı APK'yi kurup uzun `AK2JOIN:` davet metnini kendi uygulamalarının ilk ekranına yapıştırır ve **Ortak Takip** e-posta/şifresiyle giriş yaparlar. Davet metni konum şifreleme anahtarını içerir; gizlidir.

**Not:** `google-services.json` yalnızca Firebase uygulama kimlikleri içerir; güvenlik için Authentication ve bu veritabanı kuralları şarttır. Firebase ücretsiz planının da kotası vardır (10 GB/ay indirme, 1 GB saklama, 100 eşzamanlı bağlantı — güncel şartları kontrol edin). Tek aile için yerinde tasarımda genellikle yeterli, tamamen sınırsız değildir.

## Android güvenilirliği ve zorunlu testler

* 2+ saat ekran kilitliyken, evde hareketsizken, dışarı yürüyüşte ve telefon iç mekânda iken test.
* Wi-Fi/mobil veri kes-yeniden bağla; uygulamanın yeniden bağlanması.
* Android'de uygulama otomatik başlatma ve “Her zaman konum” ayarları; restart sonrası konum servisi.
* Telefon **zorla durdurulursa**, kapatılırsa, tamamen internetsiz kalırsa veya pil biterse Android garanti sunmaz. Gerçek konum en son ölçüm zamanıyla gösterilir.
* Harita OpenStreetMap/Leaflet için internet gerektirir. Veriler Firebase'e TLS + AES-GCM ile gönderilir.
* Uygulamayı babanın telefonuna kurmadan önce farklı telefonlarda gerçek şartlarda test edin.

## Build

JDK 17, Gradle 8.9, Android SDK platform/build tools 35 gerektirir.
`gradle --no-daemon assembleDebug`

Debug APK geçici geliştirme imzası kullanır; **babanın telefonuna kuracağınız nihai APK için saklanan, sabit bir release imzası** gereklidir. Debug paketini doğrudan tek seferlik kalıcı kurulum olarak kullanmayın. Aynı anahtarla imzalanmayan sonraki güncelleme eski APK'nin üzerine kurulamaz.

**Güvenlik:** Konum verilerini yalnızca `NG8ZaqUxigeNj0rhv7GjwcE5AZF3` UID’li Konum Gönderen hesabı yazabilir. `6qhia9rE3mc5hNOohtbLzj093Xq2` UID’li Ortak Takip hesabı yalnızca okuyabilir. Ortak hesabı birden fazla cihazda kullanmak mümkündür; hesap parolası veya davet metni sızarsa erişimi iptal etmek için parolayı/şifreleme anahtarını değiştirin.

**Önemli sınırlama:** Konum Gönderen yeniden başlatıldığında Firebase oturumunun geri yüklenmesi gerekir. Şifreyi uygulama kendi veritabanına kaydetmez; oturum iptal edilirse babanın telefonunda yeniden giriş gereklidir. Bu nedenle cihazda uzun süreli test şarttır.

## Kaynak

Resmî Firebase Android, Authentication, Realtime Database dokümanları ve Android Foreground Services dokümanları esas alınmıştır.


## Bu kaynak paketine Firebase entegrasyonu

- `google-services.json` içeriğindeki proje adı, veritabanı URL'si ve Android paket adı kontrol edildi.
- Konum Gönderen ve Ortak Takip hesaplarının UID eşleşmesi mevcut kaynak kodda korundu.
- Uygulama açılırken Firebase bağlantısı dosyadan otomatik okunur; Firebase'in Google Services Gradle eklentisini gerektirmeyen programatik `FirebaseOptions` kullanılır.
- Yeni takip cihazında, gönderenin oluşturduğu `AK2JOIN:` davet metniyle AES anahtarı alınır. Daveti sıradan bir parola gibi koruyun.
- Paket **kaynak koddur**; derleme, Android fiziksel testleri, sürüm imzalama henüz yapılmadı.
- Debug APK teslim edilirken kalıcı güncelleme sözü verilmemeli.
