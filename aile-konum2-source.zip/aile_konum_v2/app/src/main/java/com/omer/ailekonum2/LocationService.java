package com.omer.ailekonum2;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;
import android.os.CancellationSignal;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ServerValue;
import com.google.firebase.database.ValueEventListener;
import org.json.JSONObject;
import java.util.HashMap;
import java.util.Map;

public final class LocationService extends Service {
    private static final String CHANNEL="ak2_location";
    private HandlerThread worker;
    private Handler handler;
    private LocationManager manager;
    private Hub hub;
    private DatabaseReference family;
    private DatabaseReference connectedRef;
    private ValueEventListener connectedListener;
    private final LocationListener locationListener=this::onLocation;
    private volatile boolean online=false;
    private Location latest;
    private long lastPublished=0;
    private long lastReceivedElapsed=0;
    private boolean started=false;
    private boolean permissionGranted() {
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED ||
                checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)==PackageManager.PERMISSION_GRANTED;
    }
    @Override public void onCreate() {
        super.onCreate();
        worker=new HandlerThread("AK2-location"); worker.start();
        handler=new Handler(worker.getLooper());
        manager=(LocationManager)getSystemService(LOCATION_SERVICE);
        ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(
                new NotificationChannel(CHANNEL,"Aile Konum 2 paylaşım",NotificationManager.IMPORTANCE_LOW));
    }
    private Notification notification(){
        Intent intent=new Intent(this,MainActivity.class);
        PendingIntent open=PendingIntent.getActivity(this,0,intent,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        return new Notification.Builder(this,CHANNEL)
                .setContentTitle("Aile Konum 2 etkin")
                .setContentText("Konum paylaşımı açık • Dokunarak görüntüle")
                .setSmallIcon(android.R.drawable.ic_menu_mylocation)
                .setOngoing(true).setContentIntent(open).build();
    }
    @Override public int onStartCommand(Intent i,int flags,int startId) {
        try { startForeground(202,notification()); }
        catch(Exception ex) { Settings.str(this,"error","Bildirimli servis başlatılamadı: "+ex); stopSelf(); return START_NOT_STICKY; }
        if(!Settings.running(this) || !"sender".equals(Settings.get(this,"role"))) { stopSelf(); return START_NOT_STICKY; }
        if(!permissionGranted()) { Settings.str(this,"error","Konum izni verilmemiş"); stopSelf(); return START_NOT_STICKY; }
        if(!started){ started=true; handler.post(this::authenticate); }
        return START_STICKY;
    }
    private void authenticate() {
        try {
            hub=Hub.get(this);
            if(!hub.roleAllowed("sender")) {
                Settings.str(this,"error","Firebase Konum Gönderen oturumu bulunamadı. Uygulamayı açıp giriş yapın.");
                handler.postDelayed(this::authenticate,60000L);
            } else startTracking();
        } catch(Exception ex) { Settings.str(this,"error",ex.toString()); handler.postDelayed(this::authenticate,60000); }
    }
    private void startTracking(){
        if(family!=null) return;
        family=hub.family();
        connectedRef=hub.database.getReference(".info/connected");
        connectedListener=new ValueEventListener(){
            @Override public void onDataChange(DataSnapshot snap){
                online=Boolean.TRUE.equals(snap.getValue(Boolean.class));
                if(online){
                    DatabaseReference presence=family.child("presence");
                    Map<String,Object> gone=new HashMap<>();
                    gone.put("online",false); gone.put("changedAt",ServerValue.TIMESTAMP);
                    presence.onDisconnect().updateChildren(gone,(error,ref)->{
                        if(error==null){
                            Map<String,Object> live=new HashMap<>();
                            live.put("online",true); live.put("changedAt",ServerValue.TIMESTAMP);
                            presence.updateChildren(live);
                            handler.post(()->{publishFix(latest);heartbeat();});
                        } else Settings.str(LocationService.this,"error","Sunucu bağlantı izni: "+error.getMessage());
                    });
                }
            }
            @Override public void onCancelled(DatabaseError error){ Settings.str(LocationService.this,"error","Bağlantı izleme: "+error.getMessage()); }
        };
        connectedRef.addValueEventListener(connectedListener);
        requestUpdates();
        handler.post(watchdog);
    }
    private void requestUpdates(){
        if(!permissionGranted()) return;
        try { manager.removeUpdates(locationListener); } catch(Exception ignored){}
        try { if(manager.isProviderEnabled(LocationManager.GPS_PROVIDER))
            manager.requestLocationUpdates(LocationManager.GPS_PROVIDER,10000L,0f,locationListener,worker.getLooper()); }
        catch(Exception ex){ Settings.str(this,"error","GPS: "+ex); }
        try { if(manager.isProviderEnabled(LocationManager.NETWORK_PROVIDER))
            manager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER,20000L,0f,locationListener,worker.getLooper()); }
        catch(Exception ex){ Settings.str(this,"error","Ağ konumu: "+ex); }
    }
    private void onLocation(Location loc){
        if(loc==null || !Settings.running(this)) return;
        long age=System.currentTimeMillis()-loc.getTime();
        if(age>180000L || age < -60000L) return;
        lastReceivedElapsed=SystemClock.elapsedRealtime();
        if(latest!=null && loc.getTime()<latest.getTime()-20000L) return;
        if(latest!=null && loc.getAccuracy()>latest.getAccuracy()*3f &&
              loc.getTime()-latest.getTime()<20000L) return;
        latest=loc;
        if(!online) return;
        if(SystemClock.elapsedRealtime()-lastPublished>=10000L) publishFix(loc);
    }
    private int battery(){
        BatteryManager bm=(BatteryManager)getSystemService(BATTERY_SERVICE);
        return bm==null?-1:bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY);
    }
    private void publishFix(Location loc){
        if(!online || loc==null || family==null || !Settings.running(this)) return;
        if(System.currentTimeMillis()-loc.getTime()>120000L) return;
        long now=SystemClock.elapsedRealtime();
        if(now-lastPublished<9000L) return;
        lastPublished=now;
        try{
            JSONObject fix=new JSONObject()
              .put("lat",loc.getLatitude()).put("lon",loc.getLongitude())
              .put("accuracy",loc.getAccuracy()).put("gpsAt",loc.getTime())
              .put("provider",loc.getProvider()).put("battery",battery());
            Map<String,Object> data=new HashMap<>();
            data.put("cipher",Crypto.encrypt(Settings.get(this,"code"),fix.toString()));
            data.put("serverAt",ServerValue.TIMESTAMP);
            family.child("fix").setValue(data,(error,ref)->{
                if(error!=null) Settings.str(this,"error","Konum gönderme: "+error.getMessage());
                else { Settings.str(this,"error","");Settings.str(this,"lastOk",String.valueOf(System.currentTimeMillis())); }
            });
        }catch(Exception ex){ Settings.str(this,"error","Şifreleme: "+ex); }
    }
    private void heartbeat(){
        if(!online || family==null || !Settings.running(this)) return;
        Map<String,Object> data=new HashMap<>();
        data.put("serverAt",ServerValue.TIMESTAMP);
        data.put("gpsAt",latest==null?0L:latest.getTime());
        data.put("battery",battery());
        boolean gps=false;
        try{gps=manager.isProviderEnabled(LocationManager.GPS_PROVIDER) || manager.isProviderEnabled(LocationManager.NETWORK_PROVIDER);}catch(Exception ignored){}
        data.put("locationEnabled",gps);
        family.child("heartbeat").updateChildren(data,(error,ref)->{
            if(error!=null) Settings.str(this,"error","Durum gönderme: "+error.getMessage());
        });
    }
    private final Runnable watchdog=new Runnable(){
        @Override public void run(){
            if(!Settings.running(LocationService.this)) return;
            long age=lastReceivedElapsed==0?Long.MAX_VALUE:SystemClock.elapsedRealtime()-lastReceivedElapsed;
            if(age>90000L){
                requestUpdates();
                if(Build.VERSION.SDK_INT>=30 && permissionGranted()) {
                    for(String provider:new String[]{LocationManager.NETWORK_PROVIDER,LocationManager.GPS_PROVIDER}){
                        try { if(manager.isProviderEnabled(provider)){
                            CancellationSignal signal=new CancellationSignal();
                            manager.getCurrentLocation(provider,signal,command -> handler.post(command),onCurrent -> { if(onCurrent!=null) onLocation(onCurrent); });
                        }}catch(Exception ignored){}
                    }
                }
            }
            publishFix(latest);
            heartbeat();
            handler.postDelayed(this,60000L);
        }
    };
    @Override public void onDestroy(){
        if(handler!=null) handler.removeCallbacksAndMessages(null);
        if(manager!=null) try { manager.removeUpdates(locationListener); }catch(Exception ignored){}
        if(connectedRef!=null && connectedListener!=null)connectedRef.removeEventListener(connectedListener);
        if(family!=null){
            Map<String,Object> off=new HashMap<>(); off.put("online",false); off.put("changedAt",ServerValue.TIMESTAMP);
            family.child("presence").updateChildren(off);
        }
        if(worker!=null) worker.quitSafely();
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent intent){return null;}
}
