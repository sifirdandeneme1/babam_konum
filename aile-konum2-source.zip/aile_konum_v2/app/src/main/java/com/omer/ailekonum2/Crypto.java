package com.omer.ailekonum2;

import android.util.Base64;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.nio.charset.StandardCharsets;
import javax.crypto.Cipher;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;

final class Crypto {
    private Crypto() {}
    static String generateCode() {
        byte[] bytes = new byte[20];
        new SecureRandom().nextBytes(bytes);
        StringBuilder b = new StringBuilder();
        for (byte by : bytes) b.append(String.format(java.util.Locale.US, "%02X", by & 0xff));
        return b.toString();
    }
    static String normalize(String input) {
        return input.toUpperCase(java.util.Locale.US).replaceAll("[^A-F0-9]", "");
    }
    private static byte[] digest(String content) throws Exception {
        return MessageDigest.getInstance("SHA-256").digest(content.getBytes(StandardCharsets.UTF_8));
    }
    private static SecretKeySpec key(String code) throws Exception {
        return new SecretKeySpec(digest("aile-konum-2-data:" + code), "AES");
    }
    static String encrypt(String code, String content) throws Exception {
        byte[] iv = new byte[12]; new SecureRandom().nextBytes(iv);
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.ENCRYPT_MODE, key(code), new GCMParameterSpec(128, iv));
        byte[] ciphertext = cipher.doFinal(content.getBytes(StandardCharsets.UTF_8));
        byte[] packed = new byte[iv.length + ciphertext.length];
        System.arraycopy(iv,0,packed,0,iv.length);
        System.arraycopy(ciphertext,0,packed,iv.length,ciphertext.length);
        return Base64.encodeToString(packed, Base64.NO_WRAP);
    }
    static String decrypt(String code, String packedText) throws Exception {
        byte[] packed=Base64.decode(packedText,Base64.DEFAULT);
        if(packed.length < 29) throw new IllegalArgumentException("Invalid ciphertext");
        byte[] iv=java.util.Arrays.copyOfRange(packed,0,12);
        Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.DECRYPT_MODE,key(code),new GCMParameterSpec(128,iv));
        return new String(cipher.doFinal(packed,12,packed.length-12),StandardCharsets.UTF_8);
    }
}
