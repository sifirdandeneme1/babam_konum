package com.omer.ailekonum2;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Base64;
import org.json.JSONObject;
import java.nio.charset.StandardCharsets;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;

final class Settings {
    static final String PREFS = "aile_konum_2";
    static SharedPreferences p(Context c) { return c.getSharedPreferences(PREFS,Context.MODE_PRIVATE); }
    static String get(Context c, String k) { return p(c).getString(k,""); }
    static boolean running(Context c) { return p(c).getBoolean("running",false); }
    static void str(Context c,String k,String v) { p(c).edit().putString(k,v).apply(); }
    static void running(Context c,boolean value) { p(c).edit().putBoolean("running",value).apply(); }
    // Firebase information is bundled with the APK; no JSON paste is required on the phone.
    static boolean isConfigured(Context c) {
        try { config(c); return true; } catch(Exception e) { return false; }
    }
    static JSONObject config(Context c) throws Exception {
        String saved=get(c,"config");
        if(!saved.isEmpty()) return new JSONObject(saved);
        try(InputStream input=c.getAssets().open("google-services.json");
            ByteArrayOutputStream bytes=new ByteArrayOutputStream()) {
            byte[] buffer=new byte[4096];
            int len;
            while((len=input.read(buffer))!=-1) bytes.write(buffer,0,len);
            return configFromGoogleServices(bytes.toString("UTF-8"), "");
        }
    }
    static JSONObject configFromGoogleServices(String json, String url) throws Exception {
        JSONObject raw=new JSONObject(json);
        JSONObject info=raw.getJSONObject("project_info");
        String project=info.getString("project_id");
        String db=url.trim();
        if(db.isEmpty()) db=info.optString("firebase_url","");
        if(!(db.startsWith("https://") && (db.contains(".firebasedatabase.app") || db.contains(".firebaseio.com"))))
            throw new IllegalArgumentException("Geçerli Realtime Database adresi gerekli (https://...)");
        if(db.endsWith("/")) db=db.substring(0,db.length()-1);
        org.json.JSONArray clients=raw.getJSONArray("client");
        JSONObject androidClient=null;
        for(int i=0;i<clients.length();i++){
            JSONObject candidate=clients.getJSONObject(i);
            String pkg=candidate.getJSONObject("client_info").getJSONObject("android_client_info").getString("package_name");
            if(pkg.equals("com.omer.ailekonum2")) { androidClient=candidate; break; }
        }
        if(androidClient==null) throw new IllegalArgumentException("Firebase Android paket adı com.omer.ailekonum2 olmalı");
        String appId=androidClient.getJSONObject("client_info").getString("mobilesdk_app_id");
        String key=androidClient.getJSONArray("api_key").getJSONObject(0).getString("current_key");
        return new JSONObject().put("appId",appId).put("apiKey",key).put("projectId",project).put("url",db);
    }
    static String invite(Context ctx) throws Exception {
        JSONObject object=new JSONObject().put("cfg",config(ctx)).put("code",get(ctx,"code"));
        return "AK2JOIN:" + Base64.encodeToString(object.toString().getBytes(StandardCharsets.UTF_8), Base64.NO_WRAP|Base64.URL_SAFE);
    }
    static void importInvite(Context ctx,String invitation) throws Exception {
        String input=invitation.trim();
        if(!input.startsWith("AK2JOIN:")) throw new IllegalArgumentException("Davet metni AK2JOIN: ile başlamalı");
        String encoded=input.substring(8).trim();
        JSONObject data=new JSONObject(new String(Base64.decode(encoded,Base64.URL_SAFE|Base64.NO_WRAP),StandardCharsets.UTF_8));
        JSONObject cfg=data.getJSONObject("cfg");
        String code=Crypto.normalize(data.getString("code"));
        if(code.length()!=40) throw new IllegalArgumentException("Davet kodu geçersiz");
        if(!cfg.getString("url").startsWith("https://")) throw new IllegalArgumentException("Sunucu adresi geçersiz");
        ctx.getSharedPreferences(PREFS,Context.MODE_PRIVATE).edit()
            .putString("config",cfg.toString()).putString("code",code).putString("role","viewer").apply();
    }
}
