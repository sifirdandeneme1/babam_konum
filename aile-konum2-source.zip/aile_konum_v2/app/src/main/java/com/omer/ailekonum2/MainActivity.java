package com.omer.ailekonum2;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.ValueEventListener;
import org.json.JSONObject;
import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;

public final class MainActivity extends Activity {
    private LinearLayout column;
    private TextView locationText, statusText, diagnosticText;
    private WebView map;
    private Hub hub;
    private DatabaseReference fixRef,presenceRef,heartbeatRef;
    private ValueEventListener fixListener,presenceListener,heartbeatListener;
    private final Handler ui=new Handler(Looper.getMainLooper());
    private long lastGpsAt=0,lastServerAt=0,lastHeartbeat=0;
    private boolean senderOnline=false,locationEnabled=false;
    private int battery=-1;
    private double latitude=Double.NaN, longitude=Double.NaN,accuracy=0;
    private String errorStatus="";
    private final Runnable ticker=new Runnable(){@Override public void run(){refreshStatus();ui.postDelayed(this,15000);}};
    @Override protected void onCreate(Bundle state){super.onCreate(state);show();}
    @Override protected void onResume(){super.onResume();ui.removeCallbacks(ticker);ui.post(ticker);}
    @Override protected void onPause(){ui.removeCallbacks(ticker);super.onPause();}
    @Override protected void onDestroy(){detach();if(map!=null)map.destroy();super.onDestroy();}
    private TextView text(String content,int sp){TextView v=new TextView(this);v.setText(content);v.setTextSize(sp);v.setTextColor(0xff222c35);v.setPadding(0,12,0,12);return v;}
    private Button button(String title,Runnable click){Button b=new Button(this);b.setAllCaps(false);b.setText(title);b.setOnClickListener(v->click.run());column.addView(b);return b;}
    private EditText input(String hint){EditText e=new EditText(this);e.setHint(hint);e.setTextSize(15);column.addView(e);return e;}
    private void para(String value){column.addView(text(value,16));}
    private void toast(String msg){new AlertDialog.Builder(this).setMessage(msg).setPositiveButton("Tamam",null).show();}
    private void show(){
        detach(); map=null; locationText=null; statusText=null; diagnosticText=null;
        ScrollView scroll=new ScrollView(this);
        column=new LinearLayout(this);column.setOrientation(LinearLayout.VERTICAL);column.setPadding(26,28,26,30);
        scroll.addView(column);setContentView(scroll);
        column.addView(text("Aile Konum 2",29));
        if(!Settings.isConfigured(this)){showConfig();return;}
        String role=Settings.get(this,"role");
        if(role.equals("sender") || role.equals("viewer")) {
            try {
                hub=Hub.get(this);
                if(!hub.roleAllowed(role)){showLogin(role);return;}
            } catch(Exception ex) {para("Firebase ayarları okunamadı: "+ex.getMessage());return;}
            if(role.equals("sender")){showSender();return;}
            showViewer();return;
        }
        showRole();
    }
    private void showConfig(){
        para("Firebase dosyası bulunamadı. Bu kurulum paketindeki bağlantı dosyası kontrol edilmeli. Eski çalışan APK'yi silmeyin.");
        EditText json=input("google-services.json dosyasının içeriğini yapıştır"); json.setMinLines(3);
        EditText url=input("Realtime Database adresi: https://...firebasedatabase.app");
        button("Firebase ayarlarını kaydet",()->{
            try { JSONObject cfg=Settings.configFromGoogleServices(json.getText().toString(),url.getText().toString());
                Settings.str(this,"config",cfg.toString());show();
            }catch(Exception ex){toast("Yapılandırma hatası: "+ex.getMessage());}
        });
        para("Senin veya abinin telefonu için daha kolay yöntem: Babanın telefonundan paylaşılan AK2JOIN metnini buraya yapıştırın.");
        EditText invitation=input("AK2JOIN:...");
        button("Aile davetiyle katıl",()->{
            try{Settings.importInvite(this,invitation.getText().toString());show();}
            catch(Exception ex){toast("Davet hatası: "+ex.getMessage());}
        });
    }
    private void showLogin(String role){
        para("Bu telefon için Firebase girişi gerekli: "+("sender".equals(role)?"KONUM GÖNDEREN":"ORTAK TAKİP"));
        para("Firebase Authentication bölümünde daha önce oluşturduğunuz ilgili hesabı kullanın. E-posta ve şifre hiçbir zaman konum veritabanına yazılmaz; Firebase oturumu cihazda saklanır.");
        EditText email=input("Firebase e-posta adresi");
        email.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
        EditText password=input("Firebase hesap şifresi");
        password.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);
        button("Güvenli giriş yap",()->{
            String e=email.getText().toString(), p=password.getText().toString();
            try { Hub.get(this).login(e,p,role,error->{
                password.setText("");
                if(isFinishing())return;
                if(error!=null)toast(error);
                else show();
            }); }catch(Exception ex){toast("Giriş başlatılamadı: "+ex.getMessage());}
        });
        button("Rol seçimine dön",()->{Settings.str(this,"role","");show();});
    }
    private void showRole(){
        para("Bu telefonun rolünü seçin. Konum gönderen telefonun sahibinin rızası gerekir.");
        button("Konum Gönderen (babanın telefonu)",()->{
            Settings.str(this,"code",Crypto.generateCode());Settings.str(this,"role","sender");show();
        });
        para("Takip eden telefonlar, Konum Gönderen ekranındaki 'Davet paylaş' metnini kullanarak katılmalıdır.");
        button("Takip Eden (aile üyesi)",()->{
            Settings.str(this,"role","viewer");show();
        });
    }
    private void showSender(){
        para("Bu telefon: KONUM GÖNDEREN");
        String code=Settings.get(this,"code");
        TextView codeText=text(code.replaceAll("(.{4})","$1 ").trim(),20);
        codeText.setTextIsSelectable(true);column.addView(codeText);
        para("Bu kod özel bir anahtar gibidir; yalnızca güvendiğin aile üyeleriyle paylaş.");
        button("Davet metnini paylaş",()->{
            try{ Intent share=new Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT,Settings.invite(this));
                startActivity(Intent.createChooser(share,"Aile üyesine davet gönder")); }
            catch(Exception ex){toast(ex.getMessage());}
        });
        statusText=text("Firebase bağlantısı kontrol ediliyor…",16); column.addView(statusText);
        diagnosticText=text("",14);column.addView(diagnosticText);
        button("Konum paylaşımını başlat",()->startSender());
        button("Konum paylaşımını durdur",()->{
            Settings.running(this,false);
            stopService(new Intent(this,LocationService.class));
            toast("Konum paylaşımı durduruldu."); refreshStatus();
        });
        button("OPPO / Android uygulama izinleri",()->{
            Intent intent=new Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:"+getPackageName()));startActivity(intent);
        });
        para("Önemli: Konuma 'Her zaman izin ver' seçeneğini tanıyın; pil optimizasyonu/otomatik başlatma kısıtlamalarını kapatın. Android telefonun zorla durdurduğu uygulamaları APK kendi kendine açamaz.");
        button("Bağlantıyı ve gönderimi yenile",()->refreshStatus());
        button("Ayarları sıfırla (onaylı)",this::confirmReset);
        try{hub=Hub.get(this);
            if(!hub.roleAllowed("sender")) statusText.setText("Konum gönderen hesabı oturumu kapalı. Yeniden giriş yapın.");
        }catch(Exception ex){statusText.setText(ex.toString());}
        refreshStatus();
    }
    private void startSender(){
        try { if(!Hub.get(this).roleAllowed("sender")) {toast("Önce Konum Gönderen hesabıyla giriş yapın.");show();return;} }
        catch(Exception ex){toast("Firebase oturumu açılamadı: "+ex.getMessage());return;}
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},21);
        if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED){
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION},22);
            toast("Konum iznine izin verin. Ardından konum paylaşımını tekrar başlatın.");return;
        }
        if(Build.VERSION.SDK_INT>=29 && checkSelfPermission(Manifest.permission.ACCESS_BACKGROUND_LOCATION)!=PackageManager.PERMISSION_GRANTED){
            toast("Kesintisiz arka plan takibi için uygulama izinlerinde 'Konum > Her zaman izin ver' seçeneğini açın. Sonra Başlat'a tekrar basın.");
            startActivity(new Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS,Uri.parse("package:"+getPackageName())));
            return;
        }
        Settings.running(this,true);
        try {startForegroundService(new Intent(this,LocationService.class));
            toast("Konum paylaşımı başladı. Ekran kilitlense de konum servisi çalışmaya çalışacak.");}
        catch(Exception ex){Settings.running(this,false);toast("Servis başlatılamadı: "+ex);}
        refreshStatus();
    }
    private void showViewer(){
        para("Bu telefon: TAKİP EDEN");
        final String code=Settings.get(this,"code");
        if(code.isEmpty()){
            para("Babanın telefonundaki Davet metnini paylaş seçeneğiyle üretilen AK2JOIN davetini buraya yapıştır. Daveti yalnızca güvendiğiniz kişilerle paylaşın.");
            EditText entry=input("AK2JOIN:... davet metni");
            button("Davetle eşleştir",()->{
                try { Settings.importInvite(this,entry.getText().toString()); show(); }
                catch(Exception ex) { toast("Davet geçersiz: "+ex.getMessage()); }
            });return;
        }
        statusText=text("Bağlantı kuruluyor…",17);column.addView(statusText);
        locationText=text("Gerçek konum bekleniyor…",16);column.addView(locationText);
        map=new WebView(this);
        map.getSettings().setJavaScriptEnabled(true);
        map.getSettings().setDomStorageEnabled(true);
        map.setWebViewClient(new WebViewClient(){ @Override public void onPageFinished(WebView view,String url){updateMap();} });
        column.addView(map,new LinearLayout.LayoutParams(-1,720));
        map.loadDataWithBaseURL("https://unpkg.com/",mapHtml(),"text/html","UTF-8",null);
        button("Yol tarifi aç",()->{
            if(Double.isNaN(latitude)){toast("Henüz konum alınmadı.");return;}
            Intent browser=new Intent(Intent.ACTION_VIEW,Uri.parse("https://www.google.com/maps/dir/?api=1&destination="+latitude+","+longitude));
            try {startActivity(browser);}catch(Exception ex){toast("Harita açılamadı: "+ex);}
        });
        button("Bağlantıyı tekrar dene",()->connectViewer());
        button("Bu cihazdaki eşleştirmeyi sıfırla",this::confirmReset);
        connectViewer();
    }
    private String mapHtml(){
        return "<!doctype html><html><head><meta name='viewport' content='width=device-width,initial-scale=1'>"+
                "<link rel='stylesheet' href='https://unpkg.com/leaflet@1.9.4/dist/leaflet.css'>"+
                "<style>html,body,#map{height:100%;width:100%;padding:0;margin:0}</style></head>"+
                "<body><div id='map'></div><script src='https://unpkg.com/leaflet@1.9.4/dist/leaflet.js'></script><script>"+
                "var map=L.map('map').setView([39,35],5);L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19,attribution:'© OpenStreetMap'}).addTo(map);"+
                "var pin=null,circle=null;function setPoint(lat,lon,acc){if(!pin){pin=L.marker([lat,lon]).addTo(map).bindPopup('Babam');circle=L.circle([lat,lon],{radius:acc}).addTo(map);}else{pin.setLatLng([lat,lon]);circle.setLatLng([lat,lon]);circle.setRadius(acc);}map.setView([lat,lon],17);} </script></body></html>";
    }
    private void connectViewer(){
        detach();
        if(statusText!=null)statusText.setText("Firebase oturumu açılıyor…");
        try{
            hub=Hub.get(this);
            if(!hub.roleAllowed("viewer")){
                errorStatus="Ortak Takip hesabıyla oturum açılmamış";
                refreshStatus(); return;
            }
            subscribe();
        }catch(Exception ex){errorStatus=ex.toString();refreshStatus();}
    }
    private void subscribe(){
        if(hub==null)return;
        try{
            DatabaseReference family=hub.family();
            fixRef=family.child("fix");
            fixListener=new ValueEventListener(){
                @Override public void onDataChange(DataSnapshot snap){
                    try{
                        String cipher=snap.child("cipher").getValue(String.class);
                        if(cipher==null) return;
                        JSONObject data=new JSONObject(Crypto.decrypt(Settings.get(MainActivity.this,"code"),cipher));
                        latitude=data.getDouble("lat");longitude=data.getDouble("lon");
                        accuracy=data.getDouble("accuracy");lastGpsAt=data.getLong("gpsAt");battery=data.optInt("battery",-1);
                        Long at=snap.child("serverAt").getValue(Long.class);
                        if(at!=null)lastServerAt=at;
                        updateMap();refreshStatus();
                    }catch(Exception ex){errorStatus="Konum çözümlenemedi: "+ex;refreshStatus();}
                }
                @Override public void onCancelled(DatabaseError error){errorStatus="Konum okuma hatası: "+error.getMessage();refreshStatus();}
            };
            fixRef.addValueEventListener(fixListener);
            presenceRef=family.child("presence");
            presenceListener=new ValueEventListener(){
                @Override public void onDataChange(DataSnapshot snapshot){
                    senderOnline=Boolean.TRUE.equals(snapshot.child("online").getValue(Boolean.class));refreshStatus();
                }
                @Override public void onCancelled(DatabaseError error){errorStatus="Bağlantı hatası: "+error.getMessage();refreshStatus();}
            };
            presenceRef.addValueEventListener(presenceListener);
            heartbeatRef=family.child("heartbeat");
            heartbeatListener=new ValueEventListener(){
                @Override public void onDataChange(DataSnapshot snap){
                    Long at=snap.child("serverAt").getValue(Long.class);
                    if(at!=null)lastHeartbeat=at;
                    locationEnabled=Boolean.TRUE.equals(snap.child("locationEnabled").getValue(Boolean.class));
                    refreshStatus();
                }
                @Override public void onCancelled(DatabaseError error){errorStatus="Durum hatası: "+error.getMessage();refreshStatus();}
            };
            heartbeatRef.addValueEventListener(heartbeatListener);
        }catch(Exception ex){errorStatus=ex.toString();refreshStatus();}
    }
    private void detach(){
        if(fixRef!=null && fixListener!=null)fixRef.removeEventListener(fixListener);
        if(presenceRef!=null && presenceListener!=null)presenceRef.removeEventListener(presenceListener);
        if(heartbeatRef!=null && heartbeatListener!=null)heartbeatRef.removeEventListener(heartbeatListener);
        fixRef=null;presenceRef=null;heartbeatRef=null;
    }
    private void updateMap(){
        if(map!=null && !Double.isNaN(latitude))map.evaluateJavascript("if(window.setPoint){setPoint("+latitude+","+longitude+","+accuracy+");}",null);
    }
    private String time(long ms){return ms<=0?"bilinmiyor":DateFormat.getDateTimeInstance(DateFormat.SHORT,DateFormat.MEDIUM,new Locale("tr","TR")).format(new Date(ms));}
    private String ago(long at){if(at<=0)return "bilinmiyor";long d=Math.max(0,(System.currentTimeMillis()-at)/1000L);return d<60?d+" sn":d<3600?(d/60)+" dk":(d/3600)+" sa "+(d%3600/60)+" dk";}
    private void refreshStatus(){
        if(statusText==null)return;
        String role=Settings.get(this,"role");
        if("sender".equals(role)){
            statusText.setText("Paylaşım: "+(Settings.running(this)?"AÇIK":"KAPALI")+"\nSon onaylanan gönderim: "+time(parseLong(Settings.get(this,"lastOk"))));
            if(diagnosticText!=null) diagnosticText.setText("Son hata: "+(Settings.get(this,"error").isEmpty()?"Yok":Settings.get(this,"error")));
        }else if("viewer".equals(role)){
            long gpsAge=System.currentTimeMillis()-lastGpsAt;
            boolean fresh=lastGpsAt>0 && gpsAge<90000L;
            statusText.setText((fresh?"● KONUM GÜNCEL":"⚠ KONUM ESKİ / BEKLENİYOR")+
                "\nGönderen bağlantısı: "+(senderOnline?"BAĞLI":"BAĞLI DEĞİL")+
                "\nSon bağlantı sinyali: "+ago(lastHeartbeat)+" önce"+
                "\nKonum izni/servisi: "+(locationEnabled?"Etkin":"Bilinmiyor veya devre dışı")+
                (errorStatus.isEmpty()?"":"\nHata: "+errorStatus));
            if(locationText!=null){
                locationText.setText("Son gerçek konum: "+time(lastGpsAt)+" ("+ago(lastGpsAt)+" önce)"+
                        "\nKonum sunucuya ulaştı: "+time(lastServerAt)+
                        "\nGPS doğruluğu: "+(lastGpsAt==0?"—":String.format(Locale.US,"±%.0f m",accuracy))+
                        "\nSon pil: "+(battery<0?"—":"%"+battery)+
                        (Double.isNaN(latitude)?"":"\nKoordinat: "+latitude+", "+longitude));
            }
        }
    }
    private long parseLong(String s){try{return Long.parseLong(s);}catch(Exception e){return 0;}}
    private void confirmReset(){
        new AlertDialog.Builder(this).setTitle("Eşleştirme sıfırlansın mı?")
        .setMessage("Bu telefondaki ayarlar silinir; eski v1 uygulaması etkilenmez. Devam edilsin mi?")
        .setNegativeButton("Vazgeç",null).setPositiveButton("Sıfırla",(d,w)->{
            Settings.running(this,false);stopService(new Intent(this,LocationService.class));
            Settings.p(this).edit().clear().apply();
            if(hub!=null)hub.auth.signOut();show();
        }).show();
    }
}
