package com.omer.ailekonum2;

import android.content.Context;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import org.json.JSONObject;

final class Hub {
    static final String SENDER_UID = "NG8ZaqUxigeNj0rhv7GjwcE5AZF3";
    static final String VIEWER_UID = "6qhia9rE3mc5hNOohtbLzj093Xq2";
    private static Hub singleton;
    final FirebaseAuth auth;
    final FirebaseDatabase database;
    interface Result { void complete(String error); }

    private Hub(Context context) throws Exception {
        JSONObject cfg=Settings.config(context);
        FirebaseApp app=FirebaseApp.initializeApp(context.getApplicationContext(),new FirebaseOptions.Builder()
                .setApiKey(cfg.getString("apiKey"))
                .setApplicationId(cfg.getString("appId"))
                .setProjectId(cfg.getString("projectId"))
                .setDatabaseUrl(cfg.getString("url"))
                .build(), "aile-konum2");
        if(app==null) app=FirebaseApp.getInstance("aile-konum2");
        auth=FirebaseAuth.getInstance(app);
        database=FirebaseDatabase.getInstance(app,cfg.getString("url"));
    }
    static synchronized Hub get(Context ctx) throws Exception {
        if(singleton==null) singleton=new Hub(ctx);
        return singleton;
    }
    static String expectedUid(String role) {
        return "sender".equals(role) ? SENDER_UID : "viewer".equals(role) ? VIEWER_UID : "";
    }
    boolean roleAllowed(String role) {
        FirebaseUser user=auth.getCurrentUser();
        return user!=null && user.getUid().equals(expectedUid(role));
    }
    void login(String email, String password, String role, Result result) {
        if(email.trim().isEmpty() || password.isEmpty()) { result.complete("E-posta ve şifre gerekli."); return; }
        auth.signInWithEmailAndPassword(email.trim(),password).addOnCompleteListener(t -> {
            if(!t.isSuccessful()) { result.complete("Firebase giriş hatası: "+t.getException()); return; }
            if(!roleAllowed(role)) {
                auth.signOut();
                result.complete("Bu hesap seçilen telefon rolü için yetkili değil.");
                return;
            }
            result.complete(null);
        });
    }
    DatabaseReference family() {
        if(auth.getCurrentUser()==null) throw new IllegalStateException("Firebase oturumu yok");
        return database.getReference("families").child("babam");
    }
}
